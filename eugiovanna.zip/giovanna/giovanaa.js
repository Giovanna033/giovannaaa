//loguin//////
function login(event) {
  event.preventDefault();

  let email = document.getElementById("email").value;
  let senha = document.getElementById("senha").value;
  let msg = document.getElementById("msgLogin");

  let usuario = JSON.parse(localStorage.getItem("usuario"));

  if (!usuario || email !== usuario.email || senha !== usuario.senha) {
    msg.innerHTML = "<span style='color:red;'>Usuário ou senha inválidos</span>";
    return;
  }

  localStorage.setItem("logado", "true");

  msg.innerHTML = "<span style='color:#00ff88;'>✔ Login realizado!</span>";

  setTimeout(() => {
    window.location.href = "home.html";
  }, 1000);
}

function entrarSemLogin() {
  window.location.href = "home.html";

}
//cadastrar//////////
function cadastrar(event) {
  event.preventDefault();

  let nome = document.getElementById("nome").value;
  let email = document.getElementById("email").value;
  let senha = document.getElementById("senha").value;
  let msg = document.getElementById("msgCadastro");

  let usuario = {
    nome: nome,
    email: email,
    senha: senha
  };

  localStorage.setItem("usuario", JSON.stringify(usuario));

  msg.innerHTML = "<span style='color:#00ff88;'>✔ Cadastro realizado!</span>";

  localStorage.setItem("usuario", JSON.stringify(usuario));

// já deixa logado
  localStorage.setItem("logado", "true");

  msg.innerHTML = "<span style='color:#00ff88;'>✔ Cadastro realizado!</span>";

  setTimeout(() => {
    window.location.href = "home.html";
  }, 1000);
}
//carrinho//////
let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

let lista = document.getElementById("listaCarrinho");
let total = 0;

carrinho.forEach(item => {
    lista.innerHTML += `
        <div class="card">
            <h3>${item.nome}</h3>
            <p>R$ ${item.preco}</p>
        </div>
    `;
    total += item.preco;
  function finalizarCompra() {
    let logado = localStorage.getItem("logado");

    if (!logado) {
      alert("Você precisa fazer login para finalizar a compra!");
      window.location.href = "login.html";
      return;
    }

    let tipo = document.getElementById("pagamento").value;

    if (!tipo) {
      alert("Selecione uma forma de pagamento!");
      return;
    }

    alert("Compra finalizada com sucesso! ✨");

    localStorage.removeItem("carrinho");
    window.location.href = "home.html";
  }
});

document.getElementById("total").innerText = "Total: R$ " + total.toFixed(2);

function finalizarCompra() {
  let logado = localStorage.getItem("logado");

  if (!logado) {
    alert("Você precisa fazer login ou cadastro para continuar!");
    window.location.href = "login.html";
    return;
  }

  let tipo = document.getElementById("pagamento").value;

  if (!tipo) {
    alert("Selecione uma forma de pagamento!");
    return;
  }

  alert("Compra finalizada com sucesso! ✨");

  localStorage.removeItem("carrinho");
  window.location.href = "home.html";
}
//recomendação///////////
let pele = localStorage.getItem("pele");
let fragrancia = localStorage.getItem("fragrancia");

let resultado = document.getElementById("resultado");

// lógica simples de recomendação
if (pele === "oleosa") {
    resultado.innerHTML += `
        <div class="card">
            <h3>Sérum Oil Control</h3>
            <p>Ideal para pele oleosa</p>
            <span>R$ 60,00</span>
        </div>
    `;
}
// avaliação/////////
if (fragrancia === "doce") {
    resultado.innerHTML += `
        <div class="card">
            <h3>Perfume Doce</h3>
            <p>Fragrância marcante</p>
            <span>R$ 120,00</span>
        </div>
    `;
}
function gerarRecomendacao() {
    let pele = document.getElementById("pele").value;
    let fragrancia = document.getElementById("fragrancia").value;

    if (pele === "" || fragrancia === "") {
        alert("Preencha todas as opções!");
        return;
    }

    // salva dados (simulação)
    localStorage.setItem("pele", pele);
    localStorage.setItem("fragrancia", fragrancia);

    // redireciona
    window.location.href = "recomendacao.html";
}
//produtos//////

function adicionarCarrinho(nome, preco) {
  // 1. Busca o carrinho atual ou cria um array vazio se não existir
  let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

  // 2. Tenta encontrar se o produto já está no carrinho
  let produtoExistente = carrinho.find(item => item.nome === nome);

  if (produtoExistente) {
    // Se já existe, apenas aumenta a quantidade (opcional)
    produtoExistente.quantidade = (produtoExistente.quantidade || 1) + 1;
  } else {
    // Se é novo, adiciona com quantidade 1
    carrinho.push({ nome: nome, preco: preco, quantidade: 1 });
  }

  // 3. Salva de volta no localStorage
  localStorage.setItem("carrinho", JSON.stringify(carrinho));
  alert(`${nome} foi para o seu carrinho! 🛒`);
}

function curtirProduto(nome) {
  let favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];

  // Verifica se já não foi curtido antes para não repetir
  if (!favoritos.some(f => f.nome === nome)) {
    favoritos.push({ nome: nome });
    localStorage.setItem("favoritos", JSON.stringify(favoritos));
    alert("Adicionado aos favoritos ❤️");
  } else {
    alert("Este produto já está nos seus favoritos!");
  }
}
// USUÁRIO //////
let usuario = JSON.parse(localStorage.getItem("usuario"));
document.getElementById("nome").innerText = "Nome: " + usuario.nome;
document.getElementById("email").innerText = "Email: " + usuario.email;

// CARRINHO
let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
let lista = document.getElementById("itensCarrinho");

carrinho.forEach(item => {
  lista.innerHTML += `<p>${item.nome} - R$ ${item.preco}</p>`;
});

// FAVORITOS (simulação)
let favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];
let favDiv = document.getElementById("favoritos");

if (favoritos.length === 0) {
  favDiv.innerHTML = "<p>Nenhum item curtido</p>";
} else {
  favoritos.forEach(item => {
    favDiv.innerHTML += `<p>${item.nome}</p>`;
  });
}
function curtirProduto(nome) {
  let favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];

  favoritos.push({ nome: nome });

  localStorage.setItem("favoritos", JSON.stringify(favoritos));

  alert("Adicionado aos favoritos ❤️");
}

// LOGOUT
function logout() {
  localStorage.removeItem("logado");
  window.location.href = "login.html";
}
